package com.courseqa.service;

import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class EmbeddingService {
    public String embedAsJson(String text, int dimension) {
        double[] vector = embed(text, dimension);
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < vector.length; i++) {
            if (i > 0) sb.append(",");
            sb.append(String.format(Locale.US, "%.6f", vector[i]));
        }
        sb.append("]");
        return sb.toString();
    }

    public double[] embed(String text, int dimension) {
        double[] v = new double[dimension];
        if (text == null) return v;
        for (String word : text.toLowerCase().split("\\W+")) {
            if (!word.isBlank()) {
                v[Math.abs(word.hashCode()) % dimension] += 1.0;
            }
        }
        return v;
    }

    public double keywordSimilarity(String question, String content) {
        if (question == null || content == null) return 0.0;
        Set<String> q = new HashSet<>(Arrays.asList(question.toLowerCase().split("\\W+")));
        Set<String> c = new HashSet<>(Arrays.asList(content.toLowerCase().split("\\W+")));
        q.remove("");
        c.remove("");
        if (q.isEmpty() || c.isEmpty()) return 0.0;
        int hit = 0;
        for (String w : q) if (c.contains(w)) hit++;
        return hit / Math.sqrt(q.size() * c.size());
    }
}
