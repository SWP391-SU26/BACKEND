package com.courseqa.service;

import com.courseqa.exception.ResourceNotFoundException;
import com.courseqa.model.dto.ChatDto;
import com.courseqa.model.dto.ExperimentDto;
import com.courseqa.model.entity.*;
import com.courseqa.repository.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class EvaluationService {
    private final EvaluationQuestionRepository questionRepository;
    private final ExperimentRepository experimentRepository;
    private final ExperimentResultRepository resultRepository;
    private final ChatService chatService;

    public EvaluationService(EvaluationQuestionRepository questionRepository, ExperimentRepository experimentRepository,
                             ExperimentResultRepository resultRepository, ChatService chatService) {
        this.questionRepository = questionRepository;
        this.experimentRepository = experimentRepository;
        this.resultRepository = resultRepository;
        this.chatService = chatService;
    }

    public Experiment createExperiment(ExperimentDto.CreateExperimentRequest req) {
        Experiment e = new Experiment();
        e.setDatasetId(req.datasetId);
        e.setCourseId(req.courseId);
        e.setWorkspaceId(req.workspaceId);
        e.setExperimentName(req.experimentName);
        e.setExperimentType(req.experimentType);
        e.setLlmModel(req.llmModel);
        e.setEmbeddingModelId(req.embeddingModelId);
        e.setChunkingStrategy(req.chunkingStrategy);
        e.setTopK(req.topK);
        e.setTemperature(req.temperature);
        e.setStatus("PENDING");
        e.setCreatedBy(req.createdBy);
        e.setCreatedAt(LocalDateTime.now());
        e.setUpdatedAt(LocalDateTime.now());
        return experimentRepository.save(e);
    }

    public List<ExperimentResult> runExperiment(UUID experimentId, UUID chatSessionId) {
        Experiment experiment = experimentRepository.findById(experimentId).orElseThrow(() -> new ResourceNotFoundException("Experiment not found"));
        experiment.setStatus("RUNNING");
        experiment.setStartedAt(LocalDateTime.now());
        experimentRepository.save(experiment);

        List<EvaluationQuestion> questions = questionRepository.findByDatasetIdOrderByQuestionNo(experiment.getDatasetId());

        for (EvaluationQuestion q : questions) {
            ChatDto.AskRequest ask = new ChatDto.AskRequest();
            ask.question = q.getQuestionText();
            ask.topK = experiment.getTopK();

            ChatDto.AskResponse response = chatService.ask(chatSessionId, ask);
            double score = simpleScore(response.answer, q.getGroundTruthAnswer());

            ExperimentResult r = new ExperimentResult();
            r.setExperimentId(experimentId);
            r.setEvaluationQuestionId(q.getEvaluationQuestionId());
            r.setGeneratedAnswer(response.answer);
            r.setAnswerCorrectness(score);
            r.setAnswerRelevance(score);
            r.setFaithfulness(response.citations.isEmpty() ? 0.0 : 0.7);
            r.setContextPrecision(response.citations.isEmpty() ? 0.0 : 0.7);
            r.setContextRecall(score);
            r.setSemanticSimilarity(score);
            r.setCreatedAt(LocalDateTime.now());
            resultRepository.save(r);
        }

        experiment.setStatus("COMPLETED");
        experiment.setCompletedAt(LocalDateTime.now());
        experiment.setUpdatedAt(LocalDateTime.now());
        experimentRepository.save(experiment);

        return resultRepository.findByExperimentId(experimentId);
    }

    private double simpleScore(String answer, String truth) {
        if (answer == null || truth == null) return 0.0;
        String[] words = truth.toLowerCase().split("\\W+");
        int total = 0, hit = 0;
        for (String w : words) {
            if (w.length() < 4) continue;
            total++;
            if (answer.toLowerCase().contains(w)) hit++;
        }
        return total == 0 ? 0.0 : Math.min(1.0, hit / (double) total);
    }
}
