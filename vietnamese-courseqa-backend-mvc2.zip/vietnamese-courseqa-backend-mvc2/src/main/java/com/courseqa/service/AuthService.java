package com.courseqa.service;

import com.courseqa.exception.ResourceNotFoundException;
import com.courseqa.model.dto.AuthDto;
import com.courseqa.model.entity.User;
import com.courseqa.model.entity.UserRole;
import com.courseqa.repository.UserRepository;
import com.courseqa.repository.UserRoleRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class AuthService {
    private final UserRepository userRepository;
    private final UserRoleRepository roleRepository;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public AuthService(UserRepository userRepository, UserRoleRepository roleRepository) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
    }

    public AuthDto.AuthResponse register(AuthDto.RegisterRequest request) {
        if (userRepository.findByEmail(request.email).isPresent()) {
            throw new IllegalArgumentException("Email already exists");
        }

        User user = new User();
        user.setFullName(request.fullName);
        user.setEmail(request.email);
        user.setPasswordHash(encoder.encode(request.password));
        user.setIsActive(true);
        user.setCreatedAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        user = userRepository.save(user);

        UserRole role = new UserRole();
        role.setUserId(user.getUserId());
        role.setRoleName(request.roleName == null ? "STUDENT" : request.roleName);
        role.setPermissionJson(defaultPermission(role.getRoleName()));
        role.setAssignedAt(LocalDateTime.now());
        role.setIsActive(true);
        roleRepository.save(role);

        return new AuthDto.AuthResponse("demo-token-" + user.getUserId(), user);
    }

    public AuthDto.AuthResponse login(AuthDto.LoginRequest request) {
        User user = userRepository.findByEmail(request.email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (!Boolean.TRUE.equals(user.getIsActive())) {
            throw new IllegalArgumentException("User is inactive");
        }

        if (!encoder.matches(request.password, user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid password");
        }

        user.setLastLoginAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        userRepository.save(user);

        return new AuthDto.AuthResponse("demo-token-" + user.getUserId(), user);
    }

    public void logout(UUID userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        user.setLastLogoutAt(LocalDateTime.now());
        user.setUpdatedAt(LocalDateTime.now());
        userRepository.save(user);
    }

    private String defaultPermission(String role) {
        return switch (role) {
            case "ADMIN" -> "{\"all\":true}";
            case "TEACHER" -> "{\"courses\":true,\"documents\":true}";
            case "RESEARCHER" -> "{\"experiments\":true}";
            default -> "{\"chat\":true,\"notes\":true}";
        };
    }
}
