package com.courseqa.service;

import com.courseqa.model.entity.*;
import com.courseqa.repository.*;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.xslf.usermodel.*;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class DocumentService {
    private final CourseDocumentRepository documentRepository;
    private final DocumentPageRepository pageRepository;
    private final DocumentChunkRepository chunkRepository;
    private final EmbeddingModelRepository embeddingModelRepository;
    private final ChunkEmbeddingRepository embeddingRepository;
    private final EmbeddingService embeddingService;

    @Value("${app.upload-dir:uploads}")
    private String uploadDir;

    public DocumentService(CourseDocumentRepository documentRepository, DocumentPageRepository pageRepository,
                           DocumentChunkRepository chunkRepository, EmbeddingModelRepository embeddingModelRepository,
                           ChunkEmbeddingRepository embeddingRepository, EmbeddingService embeddingService) {
        this.documentRepository = documentRepository;
        this.pageRepository = pageRepository;
        this.chunkRepository = chunkRepository;
        this.embeddingModelRepository = embeddingModelRepository;
        this.embeddingRepository = embeddingRepository;
        this.embeddingService = embeddingService;
    }

    public CourseDocument uploadAndIndex(UUID workspaceId, UUID courseId, UUID chapterId, UUID uploadedBy, MultipartFile file) throws Exception {
        Files.createDirectories(Path.of(uploadDir));
        String original = Objects.requireNonNull(file.getOriginalFilename());
        String safe = UUID.randomUUID() + "_" + original.replaceAll("[^a-zA-Z0-9._-]", "_");
        Path target = Path.of(uploadDir, safe);
        Files.copy(file.getInputStream(), target, StandardCopyOption.REPLACE_EXISTING);

        CourseDocument doc = new CourseDocument();
        doc.setWorkspaceId(workspaceId);
        doc.setCourseId(courseId);
        doc.setChapterId(chapterId);
        doc.setUploadedBy(uploadedBy);
        doc.setDocumentTitle(original);
        doc.setOriginalFilename(original);
        doc.setFileType(extension(original));
        doc.setMimeType(file.getContentType());
        doc.setFilePath(target.toString());
        doc.setFileSizeBytes(file.getSize());
        doc.setProcessingStatus("PROCESSING");
        doc.setLanguage("vi");
        doc.setUploadedAt(LocalDateTime.now());
        doc.setUpdatedAt(LocalDateTime.now());
        doc = documentRepository.save(doc);

        try {
            String raw = extractText(target.toFile(), doc.getFileType());
            String cleaned = raw.replaceAll("\\s+", " ").trim();

            DocumentPage page = new DocumentPage();
            page.setDocumentId(doc.getDocumentId());
            page.setPageNumber(1);
            page.setRawText(raw);
            page.setCleanedText(cleaned);
            page.setWordCount(countWords(cleaned));
            page.setCharCount(cleaned.length());
            page.setExtractionStatus("TEXT_EXTRACTED");
            page.setExtractedAt(LocalDateTime.now());
            pageRepository.save(page);

            List<String> chunks = chunk(cleaned, 1200, 150);
            EmbeddingModel model = embeddingModelRepository.findByModelName("multilingual-e5-base").orElseThrow();

            int i = 1;
            for (String part : chunks) {
                DocumentChunk chunk = new DocumentChunk();
                chunk.setDocumentId(doc.getDocumentId());
                chunk.setWorkspaceId(workspaceId);
                chunk.setCourseId(courseId);
                chunk.setChapterId(chapterId);
                chunk.setChunkIndex(i++);
                chunk.setChunkStrategy("fixed_1200_150");
                chunk.setChunkSize(1200);
                chunk.setChunkOverlap(150);
                chunk.setContent(part);
                chunk.setPageStart(1);
                chunk.setPageEnd(1);
                chunk.setWordCount(countWords(part));
                chunk.setCharCount(part.length());
                chunk.setTokenCount(Math.max(1, part.length() / 4));
                chunk.setCreatedAt(LocalDateTime.now());
                chunk = chunkRepository.save(chunk);

                ChunkEmbedding emb = new ChunkEmbedding();
                emb.setChunkId(chunk.getChunkId());
                emb.setEmbeddingModelId(model.getEmbeddingModelId());
                emb.setEmbeddingJson(embeddingService.embedAsJson(part, model.getDimension()));
                emb.setDimension(model.getDimension());
                emb.setCreatedAt(LocalDateTime.now());
                embeddingRepository.save(emb);
            }

            doc.setTotalPages(1);
            doc.setProcessingStatus("INDEXED");
            doc.setUpdatedAt(LocalDateTime.now());
            return documentRepository.save(doc);
        } catch (Exception ex) {
            doc.setProcessingStatus("FAILED");
            doc.setErrorMessage(ex.getMessage());
            return documentRepository.save(doc);
        }
    }

    public List<CourseDocument> getDocumentsByWorkspace(UUID workspaceId) {
        return documentRepository.findByWorkspaceId(workspaceId);
    }

    public List<DocumentPage> getPages(UUID documentId) {
        return pageRepository.findByDocumentIdOrderByPageNumber(documentId);
    }

    public List<DocumentChunk> getChunks(UUID documentId) {
        return chunkRepository.findAll().stream().filter(c -> c.getDocumentId().equals(documentId)).toList();
    }

    private String extractText(File file, String type) throws Exception {
        return switch (type) {
            case "PDF" -> new PDFTextStripper().getText(Loader.loadPDF(file));
            case "DOCX" -> extractDocx(file);
            case "PPTX" -> extractPptx(file);
            case "TXT" -> Files.readString(file.toPath());
            default -> Files.readString(file.toPath());
        };
    }

    private String extractDocx(File file) throws Exception {
        try (XWPFDocument doc = new XWPFDocument(new FileInputStream(file))) {
            StringBuilder sb = new StringBuilder();
            doc.getParagraphs().forEach(p -> sb.append(p.getText()).append("\n"));
            return sb.toString();
        }
    }

    private String extractPptx(File file) throws Exception {
        try (XMLSlideShow ppt = new XMLSlideShow(new FileInputStream(file))) {
            StringBuilder sb = new StringBuilder();
            ppt.getSlides().forEach(slide -> {
                for (XSLFShape shape : slide.getShapes()) {
                    if (shape instanceof XSLFTextShape t) sb.append(t.getText()).append("\n");
                }
            });
            return sb.toString();
        }
    }

    private List<String> chunk(String text, int size, int overlap) {
        List<String> out = new ArrayList<>();
        int start = 0;
        while (start < text.length()) {
            int end = Math.min(start + size, text.length());
            out.add(text.substring(start, end));
            if (end == text.length()) break;
            start = Math.max(0, end - overlap);
        }
        return out;
    }

    private int countWords(String text) {
        return text == null || text.isBlank() ? 0 : text.trim().split("\\s+").length;
    }

    private String extension(String filename) {
        int i = filename.lastIndexOf(".");
        if (i < 0) return "OTHER";
        String ext = filename.substring(i + 1).toUpperCase();
        return switch (ext) {
            case "PDF", "DOCX", "PPTX", "TXT" -> ext;
            default -> "OTHER";
        };
    }
}
