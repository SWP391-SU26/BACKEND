package com.courseqa.service;

import com.courseqa.model.entity.*;
import com.courseqa.repository.*;
import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class CourseService {
    private final CourseRepository courseRepository;
    private final ChapterRepository chapterRepository;
    private final CourseWorkspaceRepository workspaceRepository;

    public CourseService(CourseRepository courseRepository, ChapterRepository chapterRepository, CourseWorkspaceRepository workspaceRepository) {
        this.courseRepository = courseRepository;
        this.chapterRepository = chapterRepository;
        this.workspaceRepository = workspaceRepository;
    }

    public List<Course> getCourses() { return courseRepository.findAll(); }

    public Course createCourse(Course course) {
        course.setIsActive(true);
        course.setCreatedAt(LocalDateTime.now());
        course.setUpdatedAt(LocalDateTime.now());
        return courseRepository.save(course);
    }

    public List<Chapter> getChapters(UUID courseId) { return chapterRepository.findByCourseId(courseId); }

    public Chapter createChapter(UUID courseId, Chapter chapter) {
        chapter.setCourseId(courseId);
        chapter.setIsActive(true);
        chapter.setCreatedAt(LocalDateTime.now());
        chapter.setUpdatedAt(LocalDateTime.now());
        return chapterRepository.save(chapter);
    }

    public List<CourseWorkspace> getWorkspaces(UUID courseId) { return workspaceRepository.findByCourseId(courseId); }

    public CourseWorkspace createWorkspace(UUID courseId, CourseWorkspace workspace) {
        workspace.setCourseId(courseId);
        workspace.setIsActive(true);
        workspace.setVisibility(workspace.getVisibility() == null ? "COURSE" : workspace.getVisibility());
        workspace.setCreatedAt(LocalDateTime.now());
        workspace.setUpdatedAt(LocalDateTime.now());
        return workspaceRepository.save(workspace);
    }
}
