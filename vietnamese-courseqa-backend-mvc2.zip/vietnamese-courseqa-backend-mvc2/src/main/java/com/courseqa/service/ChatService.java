package com.courseqa.service;

import com.courseqa.exception.ResourceNotFoundException;
import com.courseqa.model.dto.ChatDto;
import com.courseqa.model.entity.*;
import com.courseqa.repository.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;

@Service
public class ChatService {
    private final ChatSessionRepository sessionRepository;
    private final ChatMessageRepository messageRepository;
    private final DocumentChunkRepository chunkRepository;
    private final CourseDocumentRepository documentRepository;
    private final RetrievalQueryRepository queryRepository;
    private final RetrievalResultRepository resultRepository;
    private final AnswerCitationRepository citationRepository;
    private final EmbeddingService embeddingService;

    public ChatService(ChatSessionRepository sessionRepository, ChatMessageRepository messageRepository,
                       DocumentChunkRepository chunkRepository, CourseDocumentRepository documentRepository,
                       RetrievalQueryRepository queryRepository, RetrievalResultRepository resultRepository,
                       AnswerCitationRepository citationRepository, EmbeddingService embeddingService) {
        this.sessionRepository = sessionRepository;
        this.messageRepository = messageRepository;
        this.chunkRepository = chunkRepository;
        this.documentRepository = documentRepository;
        this.queryRepository = queryRepository;
        this.resultRepository = resultRepository;
        this.citationRepository = citationRepository;
        this.embeddingService = embeddingService;
    }

    public ChatSession createSession(ChatDto.CreateSessionRequest req) {
        ChatSession s = new ChatSession();
        s.setWorkspaceId(req.workspaceId);
        s.setUserId(req.userId);
        s.setCourseId(req.courseId);
        s.setChapterId(req.chapterId);
        s.setSessionTitle(req.title == null ? "New chat" : req.title);
        s.setSelectedChunkingStrategy("fixed_1200_150");
        s.setIsActive(true);
        s.setStartedAt(LocalDateTime.now());
        s.setUpdatedAt(LocalDateTime.now());
        return sessionRepository.save(s);
    }

    public ChatDto.AskResponse ask(UUID sessionId, ChatDto.AskRequest req) {
        ChatSession session = sessionRepository.findById(sessionId).orElseThrow(() -> new ResourceNotFoundException("Chat session not found"));

        ChatMessage userMsg = new ChatMessage();
        userMsg.setChatSessionId(sessionId);
        userMsg.setSenderRole("USER");
        userMsg.setMessageContent(req.question);
        userMsg.setCreatedAt(LocalDateTime.now());
        userMsg = messageRepository.save(userMsg);

        List<DocumentChunk> chunks = chunkRepository.findByWorkspaceId(session.getWorkspaceId());
        List<ScoredChunk> top = chunks.stream()
                .map(c -> new ScoredChunk(c, embeddingService.keywordSimilarity(req.question, c.getContent())))
                .filter(s -> s.score > 0.05)
                .sorted((a, b) -> Double.compare(b.score, a.score))
                .limit(req.topK == null ? 5 : req.topK)
                .toList();

        RetrievalQuery query = new RetrievalQuery();
        query.setChatSessionId(sessionId);
        query.setUserMessageId(userMsg.getMessageId());
        query.setWorkspaceId(session.getWorkspaceId());
        query.setQueryText(req.question);
        query.setTopK(req.topK == null ? 5 : req.topK);
        query.setSimilarityMetric("keyword");
        query.setSimilarityThreshold(0.05);
        query.setIsAnswerable(!top.isEmpty());
        query.setNoAnswerReason(top.isEmpty() ? "No related document chunks found" : null);
        query.setCreatedAt(LocalDateTime.now());
        query = queryRepository.save(query);

        String answer = top.isEmpty()
                ? "Thông tin này không có trong tài liệu đã cung cấp."
                : "Dựa trên tài liệu đã upload: " + shorten(top.get(0).chunk.getContent(), 700);

        ChatMessage botMsg = new ChatMessage();
        botMsg.setChatSessionId(sessionId);
        botMsg.setSenderRole("ASSISTANT");
        botMsg.setMessageContent(answer);
        botMsg.setLlmModel("simple-local-answerer");
        botMsg.setCreatedAt(LocalDateTime.now());
        botMsg = messageRepository.save(botMsg);

        List<ChatDto.CitationItem> citationItems = new ArrayList<>();
        int rank = 1;
        for (ScoredChunk sc : top) {
            RetrievalResult rr = new RetrievalResult();
            rr.setRetrievalQueryId(query.getRetrievalQueryId());
            rr.setChunkId(sc.chunk.getChunkId());
            rr.setDocumentId(sc.chunk.getDocumentId());
            rr.setResultRank(rank++);
            rr.setSimilarityScore(sc.score);
            rr.setCreatedAt(LocalDateTime.now());
            rr = resultRepository.save(rr);

            CourseDocument doc = documentRepository.findById(sc.chunk.getDocumentId()).orElse(null);

            AnswerCitation citation = new AnswerCitation();
            citation.setAssistantMessageId(botMsg.getMessageId());
            citation.setRetrievalResultId(rr.getRetrievalResultId());
            citation.setDocumentId(sc.chunk.getDocumentId());
            citation.setChunkId(sc.chunk.getChunkId());
            citation.setCitationOrder(rr.getResultRank());
            citation.setDocumentTitle(doc == null ? "Unknown" : doc.getDocumentTitle());
            citation.setPageStart(sc.chunk.getPageStart());
            citation.setPageEnd(sc.chunk.getPageEnd());
            citation.setQuoteText(shorten(sc.chunk.getContent(), 300));
            citation.setCreatedAt(LocalDateTime.now());
            citationRepository.save(citation);

            citationItems.add(new ChatDto.CitationItem(citation.getDocumentTitle(), citation.getPageStart(), citation.getPageEnd(), citation.getQuoteText()));
        }

        return new ChatDto.AskResponse(sessionId, userMsg.getMessageId(), botMsg.getMessageId(), answer, citationItems);
    }

    public List<ChatMessage> history(UUID sessionId) {
        return messageRepository.findByChatSessionIdOrderByCreatedAt(sessionId);
    }

    private String shorten(String text, int max) {
        if (text == null) return "";
        return text.length() <= max ? text : text.substring(0, max) + "...";
    }

    private record ScoredChunk(DocumentChunk chunk, double score) {}
}
