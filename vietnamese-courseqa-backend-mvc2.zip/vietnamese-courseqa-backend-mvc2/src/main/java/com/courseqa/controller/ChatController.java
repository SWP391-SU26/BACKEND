package com.courseqa.controller;

import com.courseqa.model.dto.*;
import com.courseqa.model.entity.*;
import com.courseqa.repository.ChatSessionRepository;
import com.courseqa.repository.SavedNoteRepository;
import com.courseqa.service.ChatService;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
@RequestMapping("/api/chat")
@CrossOrigin
public class ChatController {
    private final ChatService chatService;
    private final ChatSessionRepository sessionRepository;
    private final SavedNoteRepository noteRepository;

    public ChatController(ChatService chatService, ChatSessionRepository sessionRepository, SavedNoteRepository noteRepository) {
        this.chatService = chatService;
        this.sessionRepository = sessionRepository;
        this.noteRepository = noteRepository;
    }

    @PostMapping("/sessions")
    public ApiResponse<ChatSession> createSession(@RequestBody ChatDto.CreateSessionRequest request) {
        return ApiResponse.ok(chatService.createSession(request));
    }

    @GetMapping("/sessions/workspace/{workspaceId}")
    public ApiResponse<?> sessions(@PathVariable UUID workspaceId) {
        return ApiResponse.ok(sessionRepository.findByWorkspaceId(workspaceId));
    }

    @PostMapping("/sessions/{sessionId}/ask")
    public ApiResponse<ChatDto.AskResponse> ask(@PathVariable UUID sessionId, @RequestBody ChatDto.AskRequest request) {
        return ApiResponse.ok(chatService.ask(sessionId, request));
    }

    @GetMapping("/sessions/{sessionId}/history")
    public ApiResponse<?> history(@PathVariable UUID sessionId) {
        return ApiResponse.ok(chatService.history(sessionId));
    }

    @PostMapping("/notes")
    public ApiResponse<SavedNote> createNote(@RequestBody SavedNote note) {
        return ApiResponse.ok(noteRepository.save(note));
    }

    @GetMapping("/notes/workspace/{workspaceId}")
    public ApiResponse<?> notes(@PathVariable UUID workspaceId) {
        return ApiResponse.ok(noteRepository.findByWorkspaceId(workspaceId));
    }
}
