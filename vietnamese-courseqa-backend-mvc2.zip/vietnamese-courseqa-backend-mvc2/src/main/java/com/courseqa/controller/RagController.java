package com.courseqa.controller;

import com.courseqa.model.dto.ApiResponse;
import com.courseqa.model.entity.EmbeddingModel;
import com.courseqa.repository.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rag")
@CrossOrigin
public class RagController {
    private final EmbeddingModelRepository embeddingModelRepository;
    private final RetrievalQueryRepository retrievalQueryRepository;
    private final RetrievalResultRepository retrievalResultRepository;
    private final AnswerCitationRepository citationRepository;

    public RagController(EmbeddingModelRepository embeddingModelRepository,
                         RetrievalQueryRepository retrievalQueryRepository,
                         RetrievalResultRepository retrievalResultRepository,
                         AnswerCitationRepository citationRepository) {
        this.embeddingModelRepository = embeddingModelRepository;
        this.retrievalQueryRepository = retrievalQueryRepository;
        this.retrievalResultRepository = retrievalResultRepository;
        this.citationRepository = citationRepository;
    }

    @GetMapping("/embedding-models")
    public ApiResponse<?> models() {
        return ApiResponse.ok(embeddingModelRepository.findAll());
    }

    @PostMapping("/embedding-models")
    public ApiResponse<EmbeddingModel> createModel(@RequestBody EmbeddingModel model) {
        return ApiResponse.ok(embeddingModelRepository.save(model));
    }

    @GetMapping("/retrieval-queries")
    public ApiResponse<?> queries() {
        return ApiResponse.ok(retrievalQueryRepository.findAll());
    }

    @GetMapping("/retrieval-results")
    public ApiResponse<?> results() {
        return ApiResponse.ok(retrievalResultRepository.findAll());
    }

    @GetMapping("/citations")
    public ApiResponse<?> citations() {
        return ApiResponse.ok(citationRepository.findAll());
    }
}
