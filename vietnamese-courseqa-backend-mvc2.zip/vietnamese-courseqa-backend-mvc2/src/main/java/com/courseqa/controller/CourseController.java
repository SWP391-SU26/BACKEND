package com.courseqa.controller;

import com.courseqa.model.dto.ApiResponse;
import com.courseqa.model.entity.*;
import com.courseqa.service.CourseService;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
@RequestMapping("/api/courses")
@CrossOrigin
public class CourseController {
    private final CourseService courseService;

    public CourseController(CourseService courseService) {
        this.courseService = courseService;
    }

    @GetMapping
    public ApiResponse<?> courses() {
        return ApiResponse.ok(courseService.getCourses());
    }

    @PostMapping
    public ApiResponse<Course> createCourse(@RequestBody Course course) {
        return ApiResponse.ok(courseService.createCourse(course));
    }

    @GetMapping("/{courseId}/chapters")
    public ApiResponse<?> chapters(@PathVariable UUID courseId) {
        return ApiResponse.ok(courseService.getChapters(courseId));
    }

    @PostMapping("/{courseId}/chapters")
    public ApiResponse<Chapter> createChapter(@PathVariable UUID courseId, @RequestBody Chapter chapter) {
        return ApiResponse.ok(courseService.createChapter(courseId, chapter));
    }

    @GetMapping("/{courseId}/workspaces")
    public ApiResponse<?> workspaces(@PathVariable UUID courseId) {
        return ApiResponse.ok(courseService.getWorkspaces(courseId));
    }

    @PostMapping("/{courseId}/workspaces")
    public ApiResponse<CourseWorkspace> createWorkspace(@PathVariable UUID courseId, @RequestBody CourseWorkspace workspace) {
        return ApiResponse.ok(courseService.createWorkspace(courseId, workspace));
    }
}
