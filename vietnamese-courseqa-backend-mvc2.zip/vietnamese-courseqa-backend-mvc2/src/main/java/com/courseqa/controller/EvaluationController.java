package com.courseqa.controller;

import com.courseqa.model.dto.*;
import com.courseqa.model.entity.*;
import com.courseqa.repository.*;
import com.courseqa.service.EvaluationService;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
@RequestMapping("/api/evaluation")
@CrossOrigin
public class EvaluationController {
    private final EvaluationDatasetRepository datasetRepository;
    private final EvaluationQuestionRepository questionRepository;
    private final ExperimentRepository experimentRepository;
    private final ExperimentResultRepository resultRepository;
    private final EvaluationService evaluationService;

    public EvaluationController(EvaluationDatasetRepository datasetRepository, EvaluationQuestionRepository questionRepository,
                                ExperimentRepository experimentRepository, ExperimentResultRepository resultRepository,
                                EvaluationService evaluationService) {
        this.datasetRepository = datasetRepository;
        this.questionRepository = questionRepository;
        this.experimentRepository = experimentRepository;
        this.resultRepository = resultRepository;
        this.evaluationService = evaluationService;
    }

    @GetMapping("/datasets")
    public ApiResponse<?> datasets() {
        return ApiResponse.ok(datasetRepository.findAll());
    }

    @PostMapping("/datasets")
    public ApiResponse<EvaluationDataset> createDataset(@RequestBody EvaluationDataset dataset) {
        return ApiResponse.ok(datasetRepository.save(dataset));
    }

    @PostMapping("/questions")
    public ApiResponse<EvaluationQuestion> createQuestion(@RequestBody EvaluationQuestion question) {
        return ApiResponse.ok(questionRepository.save(question));
    }

    @GetMapping("/datasets/{datasetId}/questions")
    public ApiResponse<?> questions(@PathVariable UUID datasetId) {
        return ApiResponse.ok(questionRepository.findByDatasetIdOrderByQuestionNo(datasetId));
    }

    @PostMapping("/experiments")
    public ApiResponse<Experiment> createExperiment(@RequestBody ExperimentDto.CreateExperimentRequest request) {
        return ApiResponse.ok(evaluationService.createExperiment(request));
    }

    @GetMapping("/experiments")
    public ApiResponse<?> experiments() {
        return ApiResponse.ok(experimentRepository.findAll());
    }

    @PostMapping("/experiments/{experimentId}/run")
    public ApiResponse<?> run(@PathVariable UUID experimentId, @RequestParam UUID chatSessionId) {
        return ApiResponse.ok(evaluationService.runExperiment(experimentId, chatSessionId));
    }

    @GetMapping("/experiments/{experimentId}/results")
    public ApiResponse<?> results(@PathVariable UUID experimentId) {
        return ApiResponse.ok(resultRepository.findByExperimentId(experimentId));
    }
}
