package com.courseqa.controller;

import com.courseqa.model.dto.*;
import com.courseqa.service.AuthService;
import com.courseqa.repository.UserRepository;
import com.courseqa.repository.UserRoleRepository;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin
public class AuthController {
    private final AuthService authService;
    private final UserRepository userRepository;
    private final UserRoleRepository roleRepository;

    public AuthController(AuthService authService, UserRepository userRepository, UserRoleRepository roleRepository) {
        this.authService = authService;
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
    }

    @PostMapping("/register")
    public ApiResponse<AuthDto.AuthResponse> register(@RequestBody AuthDto.RegisterRequest request) {
        return ApiResponse.ok(authService.register(request));
    }

    @PostMapping("/login")
    public ApiResponse<AuthDto.AuthResponse> login(@RequestBody AuthDto.LoginRequest request) {
        return ApiResponse.ok(authService.login(request));
    }

    @PostMapping("/logout/{userId}")
    public ApiResponse<String> logout(@PathVariable UUID userId) {
        authService.logout(userId);
        return ApiResponse.ok("Logged out");
    }

    @GetMapping("/users")
    public ApiResponse<?> users() {
        return ApiResponse.ok(userRepository.findAll());
    }

    @GetMapping("/users/{userId}/roles")
    public ApiResponse<?> roles(@PathVariable UUID userId) {
        return ApiResponse.ok(roleRepository.findByUserId(userId));
    }
}
