package com.courseqa.controller;

import com.courseqa.model.dto.ApiResponse;
import com.courseqa.model.entity.CourseDocument;
import com.courseqa.service.DocumentService;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.UUID;

@RestController
@RequestMapping("/api/documents")
@CrossOrigin
public class DocumentController {
    private final DocumentService documentService;

    public DocumentController(DocumentService documentService) {
        this.documentService = documentService;
    }

    @PostMapping("/upload")
    public ApiResponse<CourseDocument> upload(
            @RequestParam UUID workspaceId,
            @RequestParam UUID courseId,
            @RequestParam(required = false) UUID chapterId,
            @RequestParam(required = false) UUID uploadedBy,
            @RequestParam MultipartFile file
    ) throws Exception {
        return ApiResponse.ok(documentService.uploadAndIndex(workspaceId, courseId, chapterId, uploadedBy, file));
    }

    @GetMapping("/workspace/{workspaceId}")
    public ApiResponse<?> documents(@PathVariable UUID workspaceId) {
        return ApiResponse.ok(documentService.getDocumentsByWorkspace(workspaceId));
    }

    @GetMapping("/{documentId}/pages")
    public ApiResponse<?> pages(@PathVariable UUID documentId) {
        return ApiResponse.ok(documentService.getPages(documentId));
    }

    @GetMapping("/{documentId}/chunks")
    public ApiResponse<?> chunks(@PathVariable UUID documentId) {
        return ApiResponse.ok(documentService.getChunks(documentId));
    }
}
