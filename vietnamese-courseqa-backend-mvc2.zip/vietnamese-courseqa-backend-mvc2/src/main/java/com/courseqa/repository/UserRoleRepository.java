package com.courseqa.repository;

import com.courseqa.model.entity.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface UserRoleRepository extends JpaRepository<UserRole, UUID> {
    java.util.List<UserRole> findByUserId(UUID userId);
}
