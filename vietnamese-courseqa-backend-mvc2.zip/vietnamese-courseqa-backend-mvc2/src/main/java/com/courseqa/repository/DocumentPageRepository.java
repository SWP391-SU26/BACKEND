package com.courseqa.repository;

import com.courseqa.model.entity.DocumentPage;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface DocumentPageRepository extends JpaRepository<DocumentPage, UUID> {
    java.util.List<DocumentPage> findByDocumentIdOrderByPageNumber(UUID documentId);
}
