package com.courseqa.repository;

import com.courseqa.model.entity.RetrievalResult;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface RetrievalResultRepository extends JpaRepository<RetrievalResult, UUID> {
    java.util.List<RetrievalResult> findByRetrievalQueryIdOrderByResultRank(UUID retrievalQueryId);
}
