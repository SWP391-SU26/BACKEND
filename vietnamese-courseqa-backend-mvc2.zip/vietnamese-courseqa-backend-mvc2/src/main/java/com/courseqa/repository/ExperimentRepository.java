package com.courseqa.repository;

import com.courseqa.model.entity.Experiment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface ExperimentRepository extends JpaRepository<Experiment, UUID> {
}
