package com.courseqa.repository;

import com.courseqa.model.entity.AnswerCitation;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface AnswerCitationRepository extends JpaRepository<AnswerCitation, UUID> {
}
