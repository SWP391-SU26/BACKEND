package com.courseqa.repository;

import com.courseqa.model.entity.ChatSession;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface ChatSessionRepository extends JpaRepository<ChatSession, UUID> {
    java.util.List<ChatSession> findByWorkspaceId(UUID workspaceId);
}
