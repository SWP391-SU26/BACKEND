package com.courseqa.repository;

import com.courseqa.model.entity.EmbeddingModel;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface EmbeddingModelRepository extends JpaRepository<EmbeddingModel, UUID> {
    java.util.Optional<EmbeddingModel> findByModelName(String modelName);
}
