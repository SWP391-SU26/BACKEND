package com.courseqa.repository;

import com.courseqa.model.entity.ChunkEmbedding;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface ChunkEmbeddingRepository extends JpaRepository<ChunkEmbedding, UUID> {
}
