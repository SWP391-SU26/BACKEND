package com.courseqa.repository;

import com.courseqa.model.entity.EvaluationQuestion;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface EvaluationQuestionRepository extends JpaRepository<EvaluationQuestion, UUID> {
    java.util.List<EvaluationQuestion> findByDatasetIdOrderByQuestionNo(UUID datasetId);
}
