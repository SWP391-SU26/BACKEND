package com.courseqa.repository;

import com.courseqa.model.entity.RetrievalQuery;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface RetrievalQueryRepository extends JpaRepository<RetrievalQuery, UUID> {
}
