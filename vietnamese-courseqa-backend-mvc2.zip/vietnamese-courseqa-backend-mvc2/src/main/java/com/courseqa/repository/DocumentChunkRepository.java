package com.courseqa.repository;

import com.courseqa.model.entity.DocumentChunk;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface DocumentChunkRepository extends JpaRepository<DocumentChunk, UUID> {
    java.util.List<DocumentChunk> findByWorkspaceId(UUID workspaceId);
}
