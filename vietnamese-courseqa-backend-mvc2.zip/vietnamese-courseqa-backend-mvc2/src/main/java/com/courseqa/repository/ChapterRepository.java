package com.courseqa.repository;

import com.courseqa.model.entity.Chapter;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface ChapterRepository extends JpaRepository<Chapter, UUID> {
    java.util.List<Chapter> findByCourseId(UUID courseId);
}
