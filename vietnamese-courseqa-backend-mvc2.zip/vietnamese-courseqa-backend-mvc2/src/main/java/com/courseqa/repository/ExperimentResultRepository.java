package com.courseqa.repository;

import com.courseqa.model.entity.ExperimentResult;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface ExperimentResultRepository extends JpaRepository<ExperimentResult, UUID> {
    java.util.List<ExperimentResult> findByExperimentId(UUID experimentId);
}
