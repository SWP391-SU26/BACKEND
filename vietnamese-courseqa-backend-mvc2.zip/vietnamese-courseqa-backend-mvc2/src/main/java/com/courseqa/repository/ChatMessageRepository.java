package com.courseqa.repository;

import com.courseqa.model.entity.ChatMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, UUID> {
    java.util.List<ChatMessage> findByChatSessionIdOrderByCreatedAt(UUID chatSessionId);
}
