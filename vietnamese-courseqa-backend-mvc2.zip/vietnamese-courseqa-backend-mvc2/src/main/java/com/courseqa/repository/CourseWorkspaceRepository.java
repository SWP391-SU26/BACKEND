package com.courseqa.repository;

import com.courseqa.model.entity.CourseWorkspace;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface CourseWorkspaceRepository extends JpaRepository<CourseWorkspace, UUID> {
    java.util.List<CourseWorkspace> findByCourseId(UUID courseId);
}
