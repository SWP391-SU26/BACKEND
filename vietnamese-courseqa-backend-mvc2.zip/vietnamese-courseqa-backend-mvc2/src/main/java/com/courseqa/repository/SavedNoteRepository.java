package com.courseqa.repository;

import com.courseqa.model.entity.SavedNote;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface SavedNoteRepository extends JpaRepository<SavedNote, UUID> {
    java.util.List<SavedNote> findByWorkspaceId(UUID workspaceId);
}
