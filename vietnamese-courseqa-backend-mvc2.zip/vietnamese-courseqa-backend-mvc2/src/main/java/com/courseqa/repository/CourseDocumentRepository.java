package com.courseqa.repository;

import com.courseqa.model.entity.CourseDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface CourseDocumentRepository extends JpaRepository<CourseDocument, UUID> {
    java.util.List<CourseDocument> findByWorkspaceId(UUID workspaceId);
}
