
IF DB_ID(N'VietnameseCourseQA20DB') IS NULL
BEGIN
    CREATE DATABASE VietnameseCourseQA20DB;
END
GO

USE VietnameseCourseQA20DB;
GO

IF OBJECT_ID('experiment_results', 'U') IS NOT NULL DROP TABLE experiment_results;
IF OBJECT_ID('experiments', 'U') IS NOT NULL DROP TABLE experiments;
IF OBJECT_ID('evaluation_questions', 'U') IS NOT NULL DROP TABLE evaluation_questions;
IF OBJECT_ID('evaluation_datasets', 'U') IS NOT NULL DROP TABLE evaluation_datasets;
IF OBJECT_ID('saved_notes', 'U') IS NOT NULL DROP TABLE saved_notes;
IF OBJECT_ID('answer_citations', 'U') IS NOT NULL DROP TABLE answer_citations;
IF OBJECT_ID('retrieval_results', 'U') IS NOT NULL DROP TABLE retrieval_results;
IF OBJECT_ID('retrieval_queries', 'U') IS NOT NULL DROP TABLE retrieval_queries;
IF OBJECT_ID('chat_messages', 'U') IS NOT NULL DROP TABLE chat_messages;
IF OBJECT_ID('chat_sessions', 'U') IS NOT NULL DROP TABLE chat_sessions;
IF OBJECT_ID('chunk_embeddings', 'U') IS NOT NULL DROP TABLE chunk_embeddings;
IF OBJECT_ID('embedding_models', 'U') IS NOT NULL DROP TABLE embedding_models;
IF OBJECT_ID('document_chunks', 'U') IS NOT NULL DROP TABLE document_chunks;
IF OBJECT_ID('document_pages', 'U') IS NOT NULL DROP TABLE document_pages;
IF OBJECT_ID('course_documents', 'U') IS NOT NULL DROP TABLE course_documents;
IF OBJECT_ID('course_workspaces', 'U') IS NOT NULL DROP TABLE course_workspaces;
IF OBJECT_ID('chapters', 'U') IS NOT NULL DROP TABLE chapters;
IF OBJECT_ID('courses', 'U') IS NOT NULL DROP TABLE courses;
IF OBJECT_ID('user_roles', 'U') IS NOT NULL DROP TABLE user_roles;
IF OBJECT_ID('users', 'U') IS NOT NULL DROP TABLE users;
GO

CREATE TABLE users (
    user_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    full_name NVARCHAR(255) NOT NULL,
    email NVARCHAR(255) NOT NULL UNIQUE,
    password_hash NVARCHAR(MAX) NOT NULL,
    avatar_url NVARCHAR(MAX) NULL,
    is_active BIT NOT NULL DEFAULT 1,
    last_login_at DATETIME2 NULL,
    last_logout_at DATETIME2 NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE()
);
GO

CREATE TABLE user_roles (
    user_role_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    user_id UNIQUEIDENTIFIER NOT NULL,
    role_name NVARCHAR(50) NOT NULL,
    permission_json NVARCHAR(MAX) NULL,
    assigned_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    is_active BIT NOT NULL DEFAULT 1,
    CONSTRAINT fk_user_roles_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT chk_user_roles_role CHECK (role_name IN ('ADMIN', 'TEACHER', 'STUDENT', 'RESEARCHER'))
);
GO

CREATE TABLE courses (
    course_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    course_code NVARCHAR(50) NOT NULL UNIQUE,
    course_name NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    created_by UNIQUEIDENTIFIER NULL,
    is_active BIT NOT NULL DEFAULT 1,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_courses_created_by FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL
);
GO

CREATE TABLE chapters (
    chapter_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    course_id UNIQUEIDENTIFIER NOT NULL,
    chapter_title NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    order_index INT NOT NULL DEFAULT 1,
    is_active BIT NOT NULL DEFAULT 1,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_chapters_course FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE
);
GO

CREATE TABLE course_workspaces (
    workspace_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    course_id UNIQUEIDENTIFIER NOT NULL,
    owner_user_id UNIQUEIDENTIFIER NULL,
    workspace_title NVARCHAR(255) NOT NULL,
    description NVARCHAR(MAX) NULL,
    visibility NVARCHAR(50) NOT NULL DEFAULT 'PRIVATE',
    is_active BIT NOT NULL DEFAULT 1,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_workspaces_course FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
    CONSTRAINT fk_workspaces_owner FOREIGN KEY (owner_user_id) REFERENCES users(user_id) ON DELETE SET NULL
);
GO

CREATE TABLE course_documents (
    document_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    workspace_id UNIQUEIDENTIFIER NOT NULL,
    course_id UNIQUEIDENTIFIER NOT NULL,
    chapter_id UNIQUEIDENTIFIER NULL,
    uploaded_by UNIQUEIDENTIFIER NULL,
    document_title NVARCHAR(255) NOT NULL,
    original_filename NVARCHAR(255) NOT NULL,
    file_type NVARCHAR(20) NOT NULL,
    mime_type NVARCHAR(150) NULL,
    file_path NVARCHAR(MAX) NOT NULL,
    file_size_bytes BIGINT NULL,
    processing_status NVARCHAR(50) NOT NULL DEFAULT 'UPLOADED',
    total_pages INT NULL,
    language NVARCHAR(20) NOT NULL DEFAULT 'vi',
    error_message NVARCHAR(MAX) NULL,
    uploaded_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_docs_workspace FOREIGN KEY (workspace_id) REFERENCES course_workspaces(workspace_id) ON DELETE CASCADE,
    CONSTRAINT fk_docs_course FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE NO ACTION,
    CONSTRAINT fk_docs_chapter FOREIGN KEY (chapter_id) REFERENCES chapters(chapter_id) ON DELETE NO ACTION,
    CONSTRAINT fk_docs_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users(user_id) ON DELETE SET NULL
);
GO

CREATE TABLE document_pages (
    page_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    document_id UNIQUEIDENTIFIER NOT NULL,
    page_number INT NOT NULL,
    raw_text NVARCHAR(MAX) NULL,
    cleaned_text NVARCHAR(MAX) NULL,
    word_count INT NULL,
    char_count INT NULL,
    extraction_status NVARCHAR(50) NOT NULL DEFAULT 'TEXT_EXTRACTED',
    error_message NVARCHAR(MAX) NULL,
    extracted_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_pages_doc FOREIGN KEY (document_id) REFERENCES course_documents(document_id) ON DELETE CASCADE
);
GO

CREATE TABLE document_chunks (
    chunk_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    document_id UNIQUEIDENTIFIER NOT NULL,
    workspace_id UNIQUEIDENTIFIER NOT NULL,
    course_id UNIQUEIDENTIFIER NOT NULL,
    chapter_id UNIQUEIDENTIFIER NULL,
    chunk_index INT NOT NULL,
    chunk_strategy NVARCHAR(100) NOT NULL DEFAULT 'fixed_1200_150',
    chunk_size INT NULL,
    chunk_overlap INT NULL,
    content NVARCHAR(MAX) NOT NULL,
    page_start INT NULL,
    page_end INT NULL,
    token_count INT NULL,
    word_count INT NULL,
    char_count INT NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_chunks_doc FOREIGN KEY (document_id) REFERENCES course_documents(document_id) ON DELETE CASCADE,
    CONSTRAINT fk_chunks_workspace FOREIGN KEY (workspace_id) REFERENCES course_workspaces(workspace_id) ON DELETE NO ACTION,
    CONSTRAINT fk_chunks_course FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE NO ACTION,
    CONSTRAINT fk_chunks_chapter FOREIGN KEY (chapter_id) REFERENCES chapters(chapter_id) ON DELETE NO ACTION
);
GO

CREATE TABLE embedding_models (
    embedding_model_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    model_name NVARCHAR(150) NOT NULL UNIQUE,
    provider NVARCHAR(100) NOT NULL,
    dimension INT NOT NULL,
    is_local BIT NOT NULL DEFAULT 0,
    description NVARCHAR(MAX) NULL,
    config_json NVARCHAR(MAX) NULL,
    is_active BIT NOT NULL DEFAULT 1,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE()
);
GO

CREATE TABLE chunk_embeddings (
    chunk_embedding_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    chunk_id UNIQUEIDENTIFIER NOT NULL,
    embedding_model_id UNIQUEIDENTIFIER NOT NULL,
    embedding_json NVARCHAR(MAX) NOT NULL,
    dimension INT NOT NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_emb_chunk FOREIGN KEY (chunk_id) REFERENCES document_chunks(chunk_id) ON DELETE CASCADE,
    CONSTRAINT fk_emb_model FOREIGN KEY (embedding_model_id) REFERENCES embedding_models(embedding_model_id) ON DELETE NO ACTION
);
GO

CREATE TABLE chat_sessions (
    chat_session_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    workspace_id UNIQUEIDENTIFIER NOT NULL,
    user_id UNIQUEIDENTIFIER NULL,
    course_id UNIQUEIDENTIFIER NOT NULL,
    chapter_id UNIQUEIDENTIFIER NULL,
    session_title NVARCHAR(255) NULL,
    selected_embedding_model_id UNIQUEIDENTIFIER NULL,
    selected_chunking_strategy NVARCHAR(100) NULL,
    system_prompt NVARCHAR(MAX) NULL,
    is_active BIT NOT NULL DEFAULT 1,
    started_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_chat_workspace FOREIGN KEY (workspace_id) REFERENCES course_workspaces(workspace_id) ON DELETE CASCADE,
    CONSTRAINT fk_chat_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    CONSTRAINT fk_chat_course FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE NO ACTION,
    CONSTRAINT fk_chat_chapter FOREIGN KEY (chapter_id) REFERENCES chapters(chapter_id) ON DELETE NO ACTION
);
GO

CREATE TABLE chat_messages (
    message_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    chat_session_id UNIQUEIDENTIFIER NOT NULL,
    sender_role NVARCHAR(50) NOT NULL,
    message_content NVARCHAR(MAX) NOT NULL,
    llm_model NVARCHAR(150) NULL,
    input_tokens INT NULL,
    output_tokens INT NULL,
    total_tokens INT NULL,
    latency_ms INT NULL,
    cost DECIMAL(18, 6) NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_msg_session FOREIGN KEY (chat_session_id) REFERENCES chat_sessions(chat_session_id) ON DELETE CASCADE
);
GO

CREATE TABLE retrieval_queries (
    retrieval_query_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    chat_session_id UNIQUEIDENTIFIER NOT NULL,
    user_message_id UNIQUEIDENTIFIER NOT NULL,
    workspace_id UNIQUEIDENTIFIER NOT NULL,
    query_text NVARCHAR(MAX) NOT NULL,
    rewritten_query NVARCHAR(MAX) NULL,
    embedding_model_id UNIQUEIDENTIFIER NULL,
    top_k INT NOT NULL DEFAULT 5,
    similarity_metric NVARCHAR(50) NOT NULL DEFAULT 'keyword',
    similarity_threshold FLOAT NOT NULL DEFAULT 0.05,
    is_answerable BIT NULL,
    no_answer_reason NVARCHAR(MAX) NULL,
    latency_ms INT NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_rq_session FOREIGN KEY (chat_session_id) REFERENCES chat_sessions(chat_session_id) ON DELETE CASCADE,
    CONSTRAINT fk_rq_msg FOREIGN KEY (user_message_id) REFERENCES chat_messages(message_id) ON DELETE NO ACTION,
    CONSTRAINT fk_rq_workspace FOREIGN KEY (workspace_id) REFERENCES course_workspaces(workspace_id) ON DELETE NO ACTION
);
GO

CREATE TABLE retrieval_results (
    retrieval_result_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    retrieval_query_id UNIQUEIDENTIFIER NOT NULL,
    chunk_id UNIQUEIDENTIFIER NOT NULL,
    document_id UNIQUEIDENTIFIER NOT NULL,
    result_rank INT NOT NULL,
    similarity_score FLOAT NOT NULL,
    rerank_score FLOAT NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_rr_query FOREIGN KEY (retrieval_query_id) REFERENCES retrieval_queries(retrieval_query_id) ON DELETE CASCADE,
    CONSTRAINT fk_rr_chunk FOREIGN KEY (chunk_id) REFERENCES document_chunks(chunk_id) ON DELETE NO ACTION,
    CONSTRAINT fk_rr_doc FOREIGN KEY (document_id) REFERENCES course_documents(document_id) ON DELETE NO ACTION
);
GO

CREATE TABLE answer_citations (
    citation_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    assistant_message_id UNIQUEIDENTIFIER NOT NULL,
    retrieval_result_id UNIQUEIDENTIFIER NULL,
    document_id UNIQUEIDENTIFIER NULL,
    chunk_id UNIQUEIDENTIFIER NULL,
    citation_order INT NOT NULL DEFAULT 1,
    document_title NVARCHAR(255) NULL,
    page_start INT NULL,
    page_end INT NULL,
    quote_text NVARCHAR(MAX) NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_cite_msg FOREIGN KEY (assistant_message_id) REFERENCES chat_messages(message_id) ON DELETE NO ACTION,
    CONSTRAINT fk_cite_rr FOREIGN KEY (retrieval_result_id) REFERENCES retrieval_results(retrieval_result_id) ON DELETE NO ACTION,
    CONSTRAINT fk_cite_doc FOREIGN KEY (document_id) REFERENCES course_documents(document_id) ON DELETE NO ACTION,
    CONSTRAINT fk_cite_chunk FOREIGN KEY (chunk_id) REFERENCES document_chunks(chunk_id) ON DELETE NO ACTION
);
GO

CREATE TABLE saved_notes (
    note_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    workspace_id UNIQUEIDENTIFIER NOT NULL,
    user_id UNIQUEIDENTIFIER NULL,
    document_id UNIQUEIDENTIFIER NULL,
    chat_session_id UNIQUEIDENTIFIER NULL,
    note_title NVARCHAR(255) NOT NULL,
    note_content NVARCHAR(MAX) NOT NULL,
    note_type NVARCHAR(50) NOT NULL DEFAULT 'MANUAL',
    source_reference_json NVARCHAR(MAX) NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_note_workspace FOREIGN KEY (workspace_id) REFERENCES course_workspaces(workspace_id) ON DELETE CASCADE,
    CONSTRAINT fk_note_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);
GO

CREATE TABLE evaluation_datasets (
    dataset_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    course_id UNIQUEIDENTIFIER NOT NULL,
    workspace_id UNIQUEIDENTIFIER NULL,
    dataset_name NVARCHAR(255) NOT NULL,
    dataset_version NVARCHAR(50) NOT NULL DEFAULT 'v1',
    description NVARCHAR(MAX) NULL,
    created_by UNIQUEIDENTIFIER NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_ds_course FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE CASCADE,
    CONSTRAINT fk_ds_workspace FOREIGN KEY (workspace_id) REFERENCES course_workspaces(workspace_id) ON DELETE NO ACTION,
    CONSTRAINT fk_ds_user FOREIGN KEY (created_by) REFERENCES users(user_id) ON DELETE SET NULL
);
GO

CREATE TABLE evaluation_questions (
    evaluation_question_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    dataset_id UNIQUEIDENTIFIER NOT NULL,
    course_id UNIQUEIDENTIFIER NOT NULL,
    chapter_id UNIQUEIDENTIFIER NULL,
    question_no INT NOT NULL,
    question_text NVARCHAR(MAX) NOT NULL,
    ground_truth_answer NVARCHAR(MAX) NOT NULL,
    expected_document_id UNIQUEIDENTIFIER NULL,
    expected_page INT NULL,
    question_type NVARCHAR(50) NOT NULL DEFAULT 'FACTUAL',
    difficulty NVARCHAR(50) NOT NULL DEFAULT 'MEDIUM',
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_eq_ds FOREIGN KEY (dataset_id) REFERENCES evaluation_datasets(dataset_id) ON DELETE CASCADE,
    CONSTRAINT fk_eq_course FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE NO ACTION
);
GO

CREATE TABLE experiments (
    experiment_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    dataset_id UNIQUEIDENTIFIER NOT NULL,
    course_id UNIQUEIDENTIFIER NOT NULL,
    workspace_id UNIQUEIDENTIFIER NULL,
    experiment_name NVARCHAR(255) NOT NULL,
    experiment_type NVARCHAR(50) NOT NULL DEFAULT 'RAG',
    llm_model NVARCHAR(150) NOT NULL,
    embedding_model_id UNIQUEIDENTIFIER NULL,
    chunking_strategy NVARCHAR(100) NULL,
    top_k INT NOT NULL DEFAULT 5,
    temperature FLOAT NOT NULL DEFAULT 0.2,
    fine_tuned_model_name NVARCHAR(255) NULL,
    config_json NVARCHAR(MAX) NULL,
    status NVARCHAR(50) NOT NULL DEFAULT 'PENDING',
    created_by UNIQUEIDENTIFIER NULL,
    started_at DATETIME2 NULL,
    completed_at DATETIME2 NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    updated_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_exp_ds FOREIGN KEY (dataset_id) REFERENCES evaluation_datasets(dataset_id) ON DELETE NO ACTION,
    CONSTRAINT fk_exp_course FOREIGN KEY (course_id) REFERENCES courses(course_id) ON DELETE NO ACTION
);
GO

CREATE TABLE experiment_results (
    experiment_result_id UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    experiment_id UNIQUEIDENTIFIER NOT NULL,
    evaluation_question_id UNIQUEIDENTIFIER NOT NULL,
    generated_answer NVARCHAR(MAX) NULL,
    retrieved_context_json NVARCHAR(MAX) NULL,
    citations_json NVARCHAR(MAX) NULL,
    faithfulness FLOAT NULL,
    answer_relevance FLOAT NULL,
    context_precision FLOAT NULL,
    context_recall FLOAT NULL,
    answer_correctness FLOAT NULL,
    semantic_similarity FLOAT NULL,
    latency_ms INT NULL,
    input_tokens INT NULL,
    output_tokens INT NULL,
    total_tokens INT NULL,
    cost DECIMAL(18, 6) NULL,
    error_message NVARCHAR(MAX) NULL,
    created_at DATETIME2 NOT NULL DEFAULT GETDATE(),
    CONSTRAINT fk_res_exp FOREIGN KEY (experiment_id) REFERENCES experiments(experiment_id) ON DELETE CASCADE,
    CONSTRAINT fk_res_eq FOREIGN KEY (evaluation_question_id) REFERENCES evaluation_questions(evaluation_question_id) ON DELETE NO ACTION
);
GO

INSERT INTO users (full_name, email, password_hash)
VALUES
(N'System Admin', N'admin@example.com', N'$2a$10$Jp0D3rW6F1sVQAXP2LiV5uu9bTC2QF6GoqKQbBaMi9uz9Z4FMy5Om'),
(N'Teacher Demo', N'teacher@example.com', N'$2a$10$Jp0D3rW6F1sVQAXP2LiV5uu9bTC2QF6GoqKQbBaMi9uz9Z4FMy5Om'),
(N'Student Demo', N'student@example.com', N'$2a$10$Jp0D3rW6F1sVQAXP2LiV5uu9bTC2QF6GoqKQbBaMi9uz9Z4FMy5Om'),
(N'Researcher Demo', N'researcher@example.com', N'$2a$10$Jp0D3rW6F1sVQAXP2LiV5uu9bTC2QF6GoqKQbBaMi9uz9Z4FMy5Om');
GO

INSERT INTO user_roles (user_id, role_name, permission_json)
SELECT user_id, 'ADMIN', N'{"all":true}' FROM users WHERE email = N'admin@example.com';
INSERT INTO user_roles (user_id, role_name, permission_json)
SELECT user_id, 'TEACHER', N'{"courses":true,"documents":true}' FROM users WHERE email = N'teacher@example.com';
INSERT INTO user_roles (user_id, role_name, permission_json)
SELECT user_id, 'STUDENT', N'{"chat":true,"notes":true}' FROM users WHERE email = N'student@example.com';
INSERT INTO user_roles (user_id, role_name, permission_json)
SELECT user_id, 'RESEARCHER', N'{"experiments":true}' FROM users WHERE email = N'researcher@example.com';
GO

DECLARE @AdminId UNIQUEIDENTIFIER;
SELECT @AdminId = user_id FROM users WHERE email = N'admin@example.com';

INSERT INTO courses (course_code, course_name, description, created_by)
VALUES (N'AI101', N'Nhập môn Trí tuệ nhân tạo', N'Môn học demo cho CourseQA.', @AdminId);
GO

DECLARE @CourseId UNIQUEIDENTIFIER;
SELECT @CourseId = course_id FROM courses WHERE course_code = N'AI101';

INSERT INTO chapters (course_id, chapter_title, description, order_index)
VALUES
(@CourseId, N'Chương 1: Tổng quan về AI', N'Khái niệm và ứng dụng AI.', 1),
(@CourseId, N'Chương 2: Machine Learning', N'Học máy cơ bản.', 2),
(@CourseId, N'Chương 3: Neural Networks', N'Mạng nơ-ron.', 3);
GO

DECLARE @TeacherId UNIQUEIDENTIFIER;
DECLARE @CourseId2 UNIQUEIDENTIFIER;
SELECT @TeacherId = user_id FROM users WHERE email = N'teacher@example.com';
SELECT @CourseId2 = course_id FROM courses WHERE course_code = N'AI101';

INSERT INTO course_workspaces (course_id, owner_user_id, workspace_title, description, visibility)
VALUES (@CourseId2, @TeacherId, N'AI101 Course Workspace', N'Không gian học tập AI101.', N'COURSE');
GO

INSERT INTO embedding_models (model_name, provider, dimension, is_local, description, config_json)
VALUES
(N'multilingual-e5-base', N'local-demo', 128, 1, N'Demo embedding model.', N'{}'),
(N'text-embedding-3-small', N'OpenAI', 1536, 0, N'OpenAI embedding model.', N'{}'),
(N'PhoBERT-base', N'VinAI', 768, 1, N'Vietnamese model.', N'{}'),
(N'bge-m3', N'BAAI', 1024, 1, N'Multilingual model.', N'{}');
GO
