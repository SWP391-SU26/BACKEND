# Vietnamese CourseQA Backend - MVC2 Version

This version uses a simple MVC2-style backend structure so it is easier to understand.

## MVC2 Structure

```text
controller  -> receives API requests from frontend
service     -> contains business logic
repository  -> talks to SQL Server database
model       -> contains entity and DTO classes
```

The frontend team is the View. Backend returns JSON only.

## Folder structure

```text
src/main/java/com/courseqa
├── controller
├── service
├── repository
├── model
│   ├── entity
│   └── dto
├── exception
└── config
```

## How to run on VS Code

1. Open this folder in VS Code.
2. Install Java Extension Pack and Spring Boot Extension Pack.
3. Run SQL file:

```text
database/VietnameseCourseQA20DB.sql
```

4. Edit SQL Server password in:

```text
src/main/resources/application.properties
```

5. Run:

```text
src/main/java/com/courseqa/CourseQaApplication.java
```

or terminal:

```bash
mvn spring-boot:run
```

## Test

```http
GET http://localhost:8080/api/courses
```

Demo user passwords are `123456` for seeded users if you keep the provided BCrypt hash.
